<?php
$id_telegram = "7160773412";
$id_botTele  = "7934148483:AAFdxbZxUBqZsPSB4xfko4CQgmrg_jJ6ZuE";
?>
